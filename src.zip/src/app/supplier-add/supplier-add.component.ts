import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { SupplierHttpService } from '../supplier-http.service';

@Component({
  selector: 'app-supplier-add',
  templateUrl: './supplier-add.component.html',
  styleUrls: ['./supplier-add.component.css']
})
export class SupplierAddComponent implements OnInit {

  myForm: FormGroup;

  constructor(private fb: FormBuilder, private http: SupplierHttpService) { }

  ngOnInit(): void {
    this.myForm = this.fb.group({
      companyName: [''],
      bankAccountNumber: [''],
    })
  }

  submitForm(): void{
    const formValues = this.myForm.value;
    this.http.add(formValues).subscribe();
    this.myForm.reset();
  }

}
